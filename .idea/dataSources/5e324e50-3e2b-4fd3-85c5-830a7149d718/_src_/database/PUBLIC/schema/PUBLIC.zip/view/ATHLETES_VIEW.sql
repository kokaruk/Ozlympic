CREATE VIEW "PUBLIC".ATHLETES_VIEW AS
  SELECT
    CONCAT(UPPER(LEFT(TYPE, 2)), LPAD(ID, 4, '0')) AS "ID",
    ID                                             AS "ID_NUM",
    NAME,
    AGE,
    STATE,
    TYPE,
    TOTALPOINTS,
    COMPETETIME
  FROM PUBLIC.PARTICIPANTS
  WHERE NOT TYPE = 'referee'